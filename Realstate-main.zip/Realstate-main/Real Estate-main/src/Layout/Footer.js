import React from "react";
import { FaFacebookF } from "react-icons/fa";
import { FaFingerprint } from "react-icons/fa";
import { FaLinode } from "react-icons/fa";
import { FaInstagram } from "react-icons/fa";
import { FaYoutube } from "react-icons/fa";
import { IoLogoTwitter } from "react-icons/io";

const Footer = () => {
  return (
    <>
      <section className="bg-dark p-4">
        <div className="container">
          <div className="row">
            <div className="col-lg-4">
              <h4 className="text-white">Residential Property</h4>
              <ul className="text-secondary list-inline nav-link">
                <li>Find a property to buy</li>
                <li>Find a property to rent</li>
                <li>Castles for Sale</li>
                <li>Country Houses for Sale</li>
                <li>Equestrian Property for Sale</li>
                <li>Farms and Estates for Sale</li>
                <li>Property for Sale Chelsea</li>
                <li>Property for Sale in Channel Islands</li>
                <li>Penthouses for Sale</li>
                <li> Houses for Sale with Swimming Pool</li>
                <li>Houses for Sale with Tennis Court</li>
                <li>Houses for Sale with Parking Space</li>
                <li>New Homes for Sale in London</li>
                <li>Waterside Properties for Sale</li>
                <li>Student Lettings</li>
                <li>Tenant fees - Non ASTS</li>
                <li>Tenant fees - ASTS</li>
                <li>Landlord fees</li>
                <li>Buying FAQs</li>
                <li>Selling FAQs</li>
              </ul>

              <h6 className="text-white">RURAL CONSULTANCY</h6>
              <ul className="text-secondary list-inline">
                <li>Agricultural Consultancy</li>
                <li>Forestry Services</li>
                <li>Farms and Estates Sales</li>
                <li>Management Services</li>
                <li>Compulsory Purchase</li>
                <li>Mapping and Land Surveys</li>
                <li>Energy</li>
                <li>Agricultural Finance</li>
                <li>Viticulture</li>
              </ul>
            </div>
            <div className="col-lg-4">
              <h4 className="text-white">COMMERCIAL PROPERTY</h4>
              <ul className="text-secondary list-inline">
                <li>Commercial Property Investment</li>
                <li>Residential Property Investment</li>
                <li>International Property Investment</li>
                <li>Fund management</li>
              </ul>

              <h4 className="text-white">INVESTMENT</h4>
              <ul className="text-secondary list-inline">
                <li>Find a property to rent</li>
                <li>Find investment property</li>
                <li>Business Rates Calculator</li>
                <li>Flexible office space</li>
                <li>Offices to Rent Birmingham</li>
              </ul>

              <h4 className="text-white">Residential Property</h4>
              <ul className="text-secondary list-inline">
                <li>Find a property to buy</li>
                <li>Find a property to rent</li>
                <li>Castles for Sale</li>
                <li>Country Houses for Sale</li>
                <li>Equestrian Property for Sale</li>
                <li>Farms and Estates for Sale</li>
                <li>Property for Sale Chelsea</li>
                <li>Property for Sale in Channel Islands</li>
                <li>Penthouses for Sale</li>
                <li> Houses for Sale with Swimming Pool</li>
                <li>Houses for Sale with Tennis Court</li>
                <li>Houses for Sale with Parking Space</li>
                <li>New Homes for Sale in London</li>
                <li>Waterside Properties for Sale</li>
                <li>Student Lettings</li>
                <li>Tenant fees - Non ASTS</li>
                <li>Tenant fees - ASTS</li>
                <li>Landlord fees</li>
                <li>Buying FAQs</li>
                <li>Selling FAQs</li>
              </ul>
            </div>
            <div className="col-lg-4">
              <h4 className="text-white">ABOUT KNIGHT FRANK</h4>
              <ul className="text-secondary list-inline">
                <li>Our App</li>
                <li>Blog</li>
                <li>Research Reports</li>
                <li>ESG at Knight Frank</li>
                <li>Recruitment</li>
                <li>Knight Frank UK Estate Agents</li>
                <li>About Us</li>
                <li>Contact our Public Relations Team</li>
                <li>Gender Pay Gap Report 2019/20</li>
                <li>Gender Pay Gap Report 2021/22</li>
                <li>Client Money Protection</li>
                <li>Group Privacy Statement</li>
                <li>Privacy center</li>
                <li>Fair Processing Notice</li>
                <li>Redress scheme details</li>
                <li>Property Redress Scheme certificate</li>
                <li>Statement of Investment Principles</li>
                <li>Engagement Policy Statement</li>
                <li>Online Property Valuation</li>
                <li>Guidance to protect against fraud</li>
              </ul>
            </div>
          </div>
          <div>
            <div className="d-flex justify-content-end align-items-center flex-wrap">
              <img src="./assets/Images/footer3.jpg" alt="" className="mx-3" width={80} />
              <img src="./assets/Images/footer1.png" alt="" className="mx-3" width={80} />
              <img src="./assets/Images/footer2.png" alt="" className="mx-3" width={80} />
            </div>
          </div>
          <div>
            <hr className="text-white" />
            <div className="d-flex justify-content-between align-items-center flex-wrap">
              <div className="text-white">
                <p>STAY CONNECTED</p>
                <p>
                  Signup to <span>My Knight Frank</span>
                </p>
              </div>
              <div>
                <FaFacebookF className="text-white mx-2" size={32} />
                <FaFingerprint className="text-white mx-2" size={32}  />
                <FaLinode className="text-white mx-2" size={32}  />
                <FaYoutube className="text-white mx-2" size={32}  />
                <FaInstagram className="text-white mx-2" size={32}  />
                <IoLogoTwitter className="text-white mx-2" size={32}  />
              </div>
            </div>
          </div>
          <hr className="text-white" />
          <div className="d-flex justify-content-between align-items-center flex-wrap">
            <div className="text-white">
              <p className="text-secondary">
                Property Site Map | Group Privacy Statement | Modern Property
                Valuation | Term and Conditions
              </p>
            </div>
            <div>
              <p className="text-secondary">Copyright @ 2024 Knight Frank.</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Footer;
