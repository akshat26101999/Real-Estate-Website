/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react'

const Topbar = () => {
    return (
        <>
            <section className='bg-white p-4'>
                <div className='container'>
                    <div className='row'>
                        <div className='col-lg-6 col-md-4 col-6'>
                            <img src='./assets/Images/Logo/knightfranklogo.png' className='img-fluid' alt='' />
                        </div>
                        <div className='col-lg-6 col-md-4 d-none d-lg-block'>
                            <div className='d-flex justify-content-between align-items-center'>
                                <p>Commercial Enquiries: 020 3944 6318</p>
                                <p>Residential Enquiries: 020 3869 4758</p>
                            </div>
                            <div className='d-flex justify-content-between align-items-center'>
                                <p>UK</p>
                                <p>About</p>
                                <p>Careers</p>
                                <p>Contact Us</p>
                                <p className='theme-color'>My Knight Frank</p>
                            </div>
                        </div>
                        <div class="header-toggle d-lg-none col-md-4 col-6 d-flex justify-content-end">
                            <button data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="offcanvas offcanvas-start" id="offcanvasExample">
                    <div class="offcanvas-header">
                        <div class="offcanvas-menu offcanvas-menu-2">
                            <ul class="main-menu list-inline">
                                <button type="button" class="close-btn" data-bs-dismiss="offcanvas"><i class="flaticon-close">x</i></button>
                                <li className="main-item"><a href="#">Property services</a></li>
                                <li className='main-item'><a href="about.html">Research</a></li>
                                <li className='main-item'><a href="contact.html">Blog</a></li>
                            </ul>
                        </div>
                    </div>

                    {/* <!-- Offcanvas Body Start --> */}
                    <div class="offcanvas-body">
                        <div class="offcanvas-menu offcanvas-menu-2">
                            <ul class="main-menu list-inline">
                                <li className="main-item" ><a href="#">Careers</a></li>
                                <li className="main-item"><a href="about.html">About</a></li>
                                <li className="main-item"><a href="contact.html">Contact Us</a></li>
                                <li className="main-item"><a href="contact.html">My Knight Frank</a></li>
                                <li className="main-item"><a href="contact.html">Commercial: 020 3944 6318</a></li>
                                <li className="main-item"><a href="contact.html">Residential:02038694758</a></li>
                            </ul>
                        </div>
                    </div>
                    {/* <!-- Offcanvas Body End -->/ */}
                </div>
            </section>
        </>
    )
}

export default Topbar